from __future__ import annotations
import os, re, time
from typing import Any, Dict, List, Mapping, Optional, Sequence
from .text import safe_truncate, sentence_split, token_count

def build_context_text(bundles: Sequence[Mapping[str,Any]], max_chars: int=24000) -> str:
    parts=[]
    for b in bundles:
        parts.append(f"[Bundle {b.get('bundle_id')} | anchor={b.get('anchor_title')} | score={b.get('score')}]")
        if b.get("propositions"):
            parts.append("Propositions:")
            for p in b.get("propositions",[]): parts.append(f"- ({p.get('prop_id')} | {p.get('title')}) {p.get('text')}")
        if b.get("source_chunks"):
            parts.append("Sources:")
            for c in b.get("source_chunks",[]): parts.append(f"- [{c.get('title')} | {c.get('chunk_id')}] {c.get('text')}")
        parts.append("")
    return safe_truncate("\n".join(parts).strip(), max_chars)

def build_prompt(question: str, bundles: Sequence[Mapping[str,Any]], cfg: Optional[Mapping[str,Any]]=None) -> str:
    cfg=cfg or {}; context=build_context_text(bundles, int(cfg.get("max_context_chars",24000)))
    policy=cfg.get("answer_policy") or cfg.get("instruction") or "Answer the question using only the evidence below. Return a concise answer. If the evidence is insufficient, answer exactly: I don't know."
    return f"{policy}\n\nQuestion:\n{question}\n\nEvidence:\n{context}\n\nAnswer:"

def extractive_fallback_answer(question: str, bundles: Sequence[Mapping[str,Any]]) -> str:
    cands=[]
    for b in bundles:
        for p in b.get("propositions",[]) or []:
            if p.get("text"): cands.append(str(p["text"]))
        for c in b.get("source_chunks",[]) or []: cands.extend(sentence_split(str(c.get("text","")))[:2])
    if not cands: return "I don't know"
    q=question.lower()
    if any(x in q for x in ["occupation","profession","job"]):
        for s in cands:
            m=re.search(r"\b(?:is|was|are|were)\s+(?:an?|the)?\s*([^.;]+?)(?:\s+who\b|\s+born\b|\.)", s, flags=re.I)
            if m: return m.group(1).strip(" ,")
    return min(cands, key=lambda x: abs(token_count(x)-18))

def _resolve_model(client: Any, configured: str) -> str:
    if configured and configured.lower() not in {"auto",""}: return configured
    models=client.models.list()
    if not models.data: raise RuntimeError("vLLM /v1/models returned no models; set generation.model explicitly.")
    return models.data[0].id

def _generate_vllm(prompt: str, cfg: Mapping[str,Any]) -> Dict[str,Any]:
    try:
        from openai import OpenAI
    except Exception as e:
        raise RuntimeError("openai package is required for generation.provider=vllm") from e
    base_url=str(cfg.get("base_url") or os.environ.get("VLLM_BASE_URL") or "http://127.0.0.1:8011/v1"); api_key=str(cfg.get("api_key") or os.environ.get("VLLM_API_KEY") or "EMPTY")
    client=OpenAI(base_url=base_url, api_key=api_key, timeout=float(cfg.get("timeout_s", cfg.get("timeout", 120))))
    model=_resolve_model(client, str(cfg.get("model","auto")))
    req={"model":model,"messages":[{"role":"system","content":str(cfg.get("system_message") or cfg.get("system_prompt") or "You are a careful, evidence-grounded QA assistant.")},{"role":"user","content":prompt}],"temperature":float(cfg.get("temperature",0.0)),"max_tokens":int(cfg.get("max_new_tokens",64))}
    if cfg.get("top_p") is not None: req["top_p"]=float(cfg.get("top_p"))
    if cfg.get("stop"): req["stop"]=cfg.get("stop")
    if cfg.get("extra_body"): req["extra_body"]=dict(cfg.get("extra_body") or {})
    resp=client.chat.completions.create(**req); pred=resp.choices[0].message.content or ""; usage=getattr(resp,"usage",None)
    return {"prediction":pred.strip(),"llm_provider":"vllm","model":model,"base_url":base_url,"usage":usage.model_dump() if hasattr(usage,"model_dump") else {}}

def generate_answer(question: str, bundles: Sequence[Mapping[str,Any]], cfg: Mapping[str,Any]) -> Dict[str,Any]:
    provider=str(cfg.get("provider","none")).lower(); prompt=build_prompt(question,bundles,cfg)
    if provider in {"none","extractive","fallback","no-llm"}: return {"prediction":extractive_fallback_answer(question,bundles),"prompt":prompt,"llm_provider":"extractive_fallback"}
    if provider=="vllm":
        last=None
        for attempt in range(int(cfg.get("retries",1))+1):
            try:
                out=_generate_vllm(prompt,cfg); out["prompt"]=prompt if cfg.get("save_prompt",False) else None; return out
            except Exception as e:
                last=e
                if attempt<int(cfg.get("retries",1)): time.sleep(float(cfg.get("retry_sleep_s",2.0)))
        raise RuntimeError(f"vLLM generation failed: {last!r}")
    raise ValueError(f"Unsupported generation.provider={provider}")
