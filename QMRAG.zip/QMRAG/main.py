from __future__ import annotations
import argparse, copy, json, time
from pathlib import Path
from typing import Any, Dict, Mapping
from tabulate import tabulate
from tqdm import tqdm
from utils.data_loaders import load_dataset
from utils.eval_metrics import evaluate_predictions, summary_markdown
from utils.generation import generate_answer
from utils.indexing import LightweightEPCIndexer
from utils.embedding import build_or_load_dense_indexes
from utils.io_utils import ExperimentLogger, dump_json, dump_yaml, ensure_dir, load_yaml, now_timestamp, to_jsonable
from utils.retrieval import QueryMedoidRetriever

def parse_args():
    p=argparse.ArgumentParser(description="QMRAG: Query-conditioned Medoid RAG runner")
    p.add_argument("--config", default="config/default.yaml"); p.add_argument("--datasets", nargs="+", default=None); p.add_argument("--mode", choices=["all","index","eval"], default="all")
    p.add_argument("--timestamp", default=None); p.add_argument("--limit", type=int, default=None); p.add_argument("--corpus-limit", type=int, default=None); p.add_argument("--output-root", default=None)
    p.add_argument("--force-reindex", action="store_true"); p.add_argument("--rebuild-embeddings", action="store_true")
    p.add_argument("--no-embed", "--no-embedding", action="store_true", dest="no_embed"); p.add_argument("--no-llm", action="store_true")
    p.add_argument("--vllm-base-url", default=None); p.add_argument("--vllm-model", default=None); p.add_argument("--embedding-model-path", default=None); p.add_argument("--embedding-device", default=None)
    p.add_argument("--continue-on-error", action="store_true")
    return p.parse_args()

def apply_overrides(cfg: Dict[str,Any], args) -> Dict[str,Any]:
    cfg=copy.deepcopy(cfg)
    if args.output_root: cfg.setdefault("run",{})["output_root"]=args.output_root
    if args.no_llm: cfg.setdefault("generation",{})["provider"]="none"
    if args.vllm_base_url: cfg.setdefault("generation",{}).update({"provider":"vllm","base_url":args.vllm_base_url})
    if args.vllm_model: cfg.setdefault("generation",{}).update({"provider":"vllm","model":args.vllm_model})
    if args.no_embed:
        cfg.setdefault("indexing",{}).setdefault("embedding",{})["enabled"]=False; cfg.setdefault("retrieval",{}).setdefault("dense",{})["enabled"]=False; cfg.setdefault("retrieval",{}).setdefault("embedding",{})["enabled"]=False
    if args.embedding_model_path:
        cfg.setdefault("indexing",{}).setdefault("embedding",{})["model_path"]=args.embedding_model_path; cfg.setdefault("retrieval",{}).setdefault("embedding",{})["model_path"]=args.embedding_model_path
    if args.embedding_device:
        cfg.setdefault("indexing",{}).setdefault("embedding",{})["device"]=args.embedding_device; cfg.setdefault("retrieval",{}).setdefault("embedding",{})["device"]=args.embedding_device
    idx_emb=cfg.get("indexing",{}).get("embedding",{})
    cfg.setdefault("retrieval",{})["embedding"]={**idx_emb, **cfg.get("retrieval",{}).get("embedding",{})}
    return cfg

def index_exists(d: Path) -> bool:
    return all((d/x).exists() for x in ["chunks.jsonl","propositions.jsonl","entities.json","index_meta.json"])

def build_or_load_index(dataset: str, docs, cfg: Mapping[str,Any], out_dir: Path, logger: ExperimentLogger, force=False, rebuild_embeddings=False):
    index_dir=out_dir/"index"
    if not force and index_exists(index_dir):
        logger.log(f"Loading EPC index: {index_dir}")
        with logger.time_block("index.load", dataset=dataset): idx=LightweightEPCIndexer.load(index_dir)
    else:
        logger.log(f"Building EPC index for {dataset}: docs={len(docs)}")
        with logger.time_block("index.build_epc", dataset=dataset, num_docs=len(docs)): idx=LightweightEPCIndexer(cfg.get("indexing",{}), logger).build(docs)
        with logger.time_block("index.save_epc", dataset=dataset): LightweightEPCIndexer.save(idx,index_dir)
    logger.log("Index meta: "+json.dumps(to_jsonable(idx.get("meta",{})),ensure_ascii=False)[:1500]); return idx

def append_line(fh,row): fh.write(json.dumps(to_jsonable(row),ensure_ascii=False)+"\n"); fh.flush()

def eval_only(dataset: str, out_dir: Path, logger: ExperimentLogger):
    path=out_dir/"예측결과.jsonl" if (out_dir/"예측결과.jsonl").exists() else out_dir/"predictions.jsonl"
    rows=[json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]
    with logger.time_block("eval", dataset=dataset, n=len(rows)):
        res=evaluate_predictions(rows); dump_json(res,out_dir/"eval.json"); (out_dir/"eval_summary.md").write_text(summary_markdown(dataset,res),encoding="utf-8")
    return {"dataset":dataset, **{k:v for k,v in res.items() if k!="per_example"}}

def run_dataset(dataset: str, cfg: Dict[str,Any], args, timestamp: str):
    out_dir=ensure_dir(Path(cfg.get("run",{}).get("output_root","outputs"))/timestamp/dataset); logger=ExperimentLogger(out_dir, echo=bool(cfg.get("run",{}).get("echo_logs",True)))
    logger.log(f"Run dataset={dataset} mode={args.mode} timestamp={timestamp}"); dump_yaml(cfg,out_dir/"config.yaml")
    if args.mode=="eval": return eval_only(dataset,out_dir,logger)
    ds_cfg=cfg.get("datasets",{}).get(dataset)
    if not ds_cfg: raise ValueError(f"Dataset {dataset} not in config")
    with logger.time_block("data.load", dataset=dataset): qas,docs=load_dataset(dataset,ds_cfg,args.limit,args.corpus_limit)
    logger.log(f"Loaded QA={len(qas)} docs={len(docs)}")
    idx=build_or_load_index(dataset,docs,cfg,out_dir,logger,args.force_reindex,args.rebuild_embeddings)
    dense_indexes={}
    if cfg.get("retrieval",{}).get("dense",{}).get("enabled",False) and not args.no_embed:
        with logger.time_block("index.build_dense_indexes", dataset=dataset):
            dense_indexes=build_or_load_dense_indexes(idx,cfg.get("retrieval",{}),out_dir/"index",logger,force=args.rebuild_embeddings)
    if args.mode=="index": return {"dataset":dataset,"n":0,"status":"indexed","index_meta":idx.get("meta",{})}
    retriever=QueryMedoidRetriever(idx,cfg.get("retrieval",{}),dense_indexes,logger); preds=[]; pko=out_dir/"예측결과.jsonl"; pen=out_dir/"predictions.jsonl"
    for p in [pko,pen]:
        if p.exists(): p.unlink()
    with logger.time_block("run.examples", dataset=dataset, n=len(qas)):
        with open(pko,"a",encoding="utf-8") as fko, open(pen,"a",encoding="utf-8") as fen:
            for qa in tqdm(qas, desc=dataset, ncols=100):
                try:
                    with logger.time_block("retrieve.one", dataset=dataset, qid=qa.id): ret=retriever.retrieve(qa.question, qa.metadata)
                    t=time.perf_counter()
                    with logger.time_block("generate.one", dataset=dataset, qid=qa.id): gen=generate_answer(qa.question, ret["evidence_bundles"], cfg.get("generation",{}))
                    row={"id":qa.id,"question":qa.question,"prediction":gen.get("prediction",""),"answers":qa.answers,"support_titles":qa.support_titles,"support_facts":qa.support_facts,"evidence_bundles":ret["evidence_bundles"],"seeds":ret["seeds"],"retrieval_diagnostics":ret["diagnostics"],"generation_latency_s":round(time.perf_counter()-t,6),"llm_provider":gen.get("llm_provider"),"llm_model":gen.get("model"),"llm_usage":gen.get("usage")}
                except Exception as e:
                    logger.event({"event":"example.error","dataset":dataset,"qid":qa.id,"error":repr(e)})
                    if not args.continue_on_error: raise
                    row={"id":qa.id,"question":qa.question,"prediction":"","answers":qa.answers,"support_titles":qa.support_titles,"error":repr(e),"evidence_bundles":[],"seeds":[],"retrieval_diagnostics":{"candidate_count":0,"seed_count":0,"bundle_count":0,"context_tokens":0,"timings":{}},"generation_latency_s":0.0,"llm_provider":cfg.get("generation",{}).get("provider")}
                preds.append(row); append_line(fko,row); append_line(fen,row)
    with logger.time_block("eval", dataset=dataset, n=len(preds)):
        res=evaluate_predictions(preds); dump_json(res,out_dir/"eval.json"); (out_dir/"eval_summary.md").write_text(summary_markdown(dataset,res),encoding="utf-8")
    return {"dataset":dataset, **{k:v for k,v in res.items() if k!="per_example"}}

def main():
    args=parse_args(); cfg=apply_overrides(load_yaml(args.config), args); timestamp=args.timestamp or now_timestamp(); datasets=args.datasets or list(cfg.get("datasets",{}).keys()); rows=[]
    for ds in datasets: rows.append(run_dataset(ds,cfg,args,timestamp))
    if rows:
        table=[]
        for s in rows: table.append({"dataset":s.get("dataset"),"n":s.get("n",0),"EM":f"{s.get('em',0):.4f}" if "em" in s else "-","F1":f"{s.get('f1',0):.4f}" if "f1" in s else "-","AnsContains":f"{s.get('answer_contains',0):.4f}" if "answer_contains" in s else "-","SupportRecall":f"{s.get('support_title_recall',0):.4f}" if "support_title_recall" in s else "-","SR/1kTok":f"{s.get('support_recall_per_1k_tokens',0):.4f}" if "support_recall_per_1k_tokens" in s else "-","CtxTok":f"{s.get('context_tokens',0):.1f}" if "context_tokens" in s else "-","LatencyMs":f"{s.get('latency_ms',0):.1f}" if "latency_ms" in s else "-","DenseRate":f"{s.get('dense_enabled_rate',0):.2f}" if "dense_enabled_rate" in s else "-"})
        print("\n"+tabulate(table, headers="keys", tablefmt="github"))
if __name__=="__main__": main()
